class meuObjeto:
  def funcao(self):
    print("Essa funcao eh publica")
  
  def __funcao(self):
    print ("Essa funcao eh privada")

objeto = meuObjeto()

objeto.funcao()

#Por ser privado não pode ser usado fora da classe
objeto.__funcao()

  