for x in range(1001):
  if(x%2==0):
    print(x)